# Book-Store-Mobile-App
Mobile App using Android Studio with java and XML

This is a book selling app where you can search for the book you want
or browse our library of Arabic and English books
Choose whether you're looking for books or novels
then specify the genere

you'll then be able to see all the books we have and an overview of them
this includes their Author, rating, a brief about them, and their price

then you can add it to your cart 
and proceed to the checkout or continue browsing to explore more stuff

at the checkout you enter your details then you can choose to pay online with our secure payment service 
or choose to pay with the COD (Cash On Delivery) option

after you finish up your order you will receive an email with your order number 
and you will also be updated as to track your order

The design of this app is intuitive and easy to use
designed as a single tab with buttons to direct the user to other screens

color palette is very simple and the font use is limited for eye comfot (You can find them in the documentation file)
Dark mode option is also available
An action bar is added to easily reach importatnt options

Sign up and Sign in process are very easy and secure

Firebase database is used
